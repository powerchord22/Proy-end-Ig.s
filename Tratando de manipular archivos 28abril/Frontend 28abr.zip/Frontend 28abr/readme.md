

Breve descripción del proyecto.
   Sonalert ance con la necesidad de amntern a los veinos del municipio asesorados y conectados en denunciar, asesorarse y buscar soluciones a ruidos molestos y sus problemas asociados. Se hace imperioso hoy x hoy una solucion a un enemigho invisible que tiene tanta repercucion en el diario vivir y el descanso optimo, 
Características

    _ Asesoria en ruidos molestos e informacion en JJVV
    _ Inscripcion de nuevos vecinos en la base de datos comunal
    _ App para utilizacion en distintos municipios 

Tecnologías utilizadas

    Node.js
    Express
    PostgreSQL
    EJS
    JWT
    CSS3
    JavaScript

Requisitos previos

    Node.js instalado en tu equipo

Instrucciones para comenzar

    Clona el repositorio en tu equipo.

bash

git clone https://github.com/tuusuario/tuprojecto.git

    Navega hasta el directorio del proyecto.

bash

cd tuproyecto

    Instala las dependencias del proyecto.

bash

npm install

    Crea la base de datos en PostgreSQL.

bash

psql -U usuario -d basededatos -a -f database.sql

    Inicia el servidor.

bash

node index.js

    Visita la URL http://localhost:5000 en tu navegador para ver el resultado.

Contribuciones

Si deseas contribuir a este proyecto, por favor envía un pull request.
Licencia

Este proyecto está licenciado bajo la Licencia MIT. Para más información, por favor consulta el archivo LICENSE.
Contacto

Si tienes alguna pregunta o comentario acerca de este proyecto, por favor contáctame a través de mi correo electrónico.